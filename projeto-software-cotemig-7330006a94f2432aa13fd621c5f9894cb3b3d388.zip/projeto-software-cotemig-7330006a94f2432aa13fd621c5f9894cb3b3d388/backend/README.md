# Backend do Site da Igreja

Para rodar o projeto:

1. Execute o comando `npm i`
2. Execute o comando `npm start`
