import React from "react";

const ResponsiveNav = () => {
  return (
    <>
      <div id="two">
        <ul>
          <li>Igrejas Afiliadas</li>
          <li>Cadastrar sua Igreja</li>
          <li>Contate-nos</li>
        </ul>
      </div>
    </>
  );
};

export default ResponsiveNav;
